<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MY PORTFOLIO</title>
  <style>
    body { 
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
     background: red
      color: orange
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
    }

    .container {
      text-align: center;
      padding: 20px;
    }

    .profile-image {
      width: 150px;
      height: 150px;
      border-radius: 50%;
      object-fit: cover;
      border: 5px solid #ffffffd8;
      box-shadow: 0 0 15px rgba(0, 0, 0, 0.4);
      margin-bottom: 20px;
    }

    h1 {
      font-size: 2.5rem;
      margin: 10px 0;
      color: #333;
    }

    p {
      font-size: 1.2rem;
      color: #666;
      margin: 10px 0;
    }

    .info {
      font-size: 1rem;
      color: #55555585;
      margin: 10px 0;
    }

    .social-links {
      margin-top: 20px;
    }

    .social-links a {
      margin: 0 15px;
      font-size: 1.5rem;
      color: #333333e3;
      text-decoration: none;
      transition: color 0.3s;
    }

    .social-links a:hover {
      color: #fbff00ad;
    }

  </style>
</head>
<body style bgcolor="pink">
  <div class="container">
    <img src="" alt="Profile Picture" class="profile-image">
    <h1>pangalan mo kupal</h1>
    <p>ikaw bahala | ikaw bahala | ikaw bahala</p>
    <div class="info">
      <p>lagay mo gusto mo</p>
      <p>lagay mo gusto mo</p>
      <p>lagay mo gusto mo</p>
    </div>
    <div class="social-links">
      <a href="" target="_blank">PERSONAL FB ACC</a>
      <a href="" target="_blank">IG ACC</a>
      <a href="" target="_blank">TIKTOK ACC</a>
    </div>
  </div>
</body>
</html>
